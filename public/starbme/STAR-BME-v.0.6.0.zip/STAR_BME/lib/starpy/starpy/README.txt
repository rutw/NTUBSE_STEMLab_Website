STARPY dependence:

    Inherent package dependences: Required to be imported
        numpy >= 1.13
        scipy >= 0.15
        pandas >= 0.22
        six >=1.11

    Special package dependences: Suggested to be imported

        matplotlib >= 2.0
        nlopt >= 2.4
        rpy2 >= 2.8
            R software (>=3.4) with R's packages:
                dlnm
                mgcv
