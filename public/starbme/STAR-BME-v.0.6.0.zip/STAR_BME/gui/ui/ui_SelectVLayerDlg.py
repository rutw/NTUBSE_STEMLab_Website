# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_SelectVLayerDlg.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SelectVLayerDlg(object):
    def setupUi(self, SelectVLayerDlg):
        SelectVLayerDlg.setObjectName("SelectVLayerDlg")
        SelectVLayerDlg.setWindowModality(QtCore.Qt.WindowModal)
        SelectVLayerDlg.resize(296, 69)
        self.verticalLayout = QtWidgets.QVBoxLayout(SelectVLayerDlg)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(SelectVLayerDlg)
        self.label.setMinimumSize(QtCore.QSize(77, 16))
        self.label.setMaximumSize(QtCore.QSize(77, 16))
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.comboBox = QtWidgets.QComboBox(SelectVLayerDlg)
        self.comboBox.setMinimumSize(QtCore.QSize(171, 20))
        self.comboBox.setObjectName("comboBox")
        self.horizontalLayout.addWidget(self.comboBox)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.buttonBox = QtWidgets.QDialogButtonBox(SelectVLayerDlg)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(SelectVLayerDlg)
        QtCore.QMetaObject.connectSlotsByName(SelectVLayerDlg)

    def retranslateUi(self, SelectVLayerDlg):
        _translate = QtCore.QCoreApplication.translate
        SelectVLayerDlg.setWindowTitle(_translate("SelectVLayerDlg", "Dialog"))
        self.label.setText(_translate("SelectVLayerDlg", "Select the Layer:"))

