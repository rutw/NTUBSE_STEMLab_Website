# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_ColorBarPropertyDlg.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_ColorBarPropertyDlg(object):
    def setupUi(self, ColorBarPropertyDlg):
        ColorBarPropertyDlg.setObjectName("ColorBarPropertyDlg")
        ColorBarPropertyDlg.resize(299, 127)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(ColorBarPropertyDlg)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtWidgets.QLabel(ColorBarPropertyDlg)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.label_2 = QtWidgets.QLabel(ColorBarPropertyDlg)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        self.label_3 = QtWidgets.QLabel(ColorBarPropertyDlg)
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.horizontalLayout_3.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.comboBox_cmap = QtWidgets.QComboBox(ColorBarPropertyDlg)
        self.comboBox_cmap.setObjectName("comboBox_cmap")
        self.horizontalLayout_2.addWidget(self.comboBox_cmap)
        self.checkBox_inverse = QtWidgets.QCheckBox(ColorBarPropertyDlg)
        self.checkBox_inverse.setObjectName("checkBox_inverse")
        self.horizontalLayout_2.addWidget(self.checkBox_inverse)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.lineEdit_minvalue = QtWidgets.QLineEdit(ColorBarPropertyDlg)
        self.lineEdit_minvalue.setObjectName("lineEdit_minvalue")
        self.verticalLayout.addWidget(self.lineEdit_minvalue)
        self.lineEdit_maxvalue = QtWidgets.QLineEdit(ColorBarPropertyDlg)
        self.lineEdit_maxvalue.setObjectName("lineEdit_maxvalue")
        self.verticalLayout.addWidget(self.lineEdit_maxvalue)
        self.horizontalLayout_3.addLayout(self.verticalLayout)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton_apply = QtWidgets.QPushButton(ColorBarPropertyDlg)
        self.pushButton_apply.setObjectName("pushButton_apply")
        self.horizontalLayout.addWidget(self.pushButton_apply)
        self.pushButton_close = QtWidgets.QPushButton(ColorBarPropertyDlg)
        self.pushButton_close.setObjectName("pushButton_close")
        self.horizontalLayout.addWidget(self.pushButton_close)
        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.retranslateUi(ColorBarPropertyDlg)
        QtCore.QMetaObject.connectSlotsByName(ColorBarPropertyDlg)

    def retranslateUi(self, ColorBarPropertyDlg):
        _translate = QtCore.QCoreApplication.translate
        ColorBarPropertyDlg.setWindowTitle(_translate("ColorBarPropertyDlg", "ColorBar - Property"))
        self.label.setText(_translate("ColorBarPropertyDlg", "color map"))
        self.label_2.setText(_translate("ColorBarPropertyDlg", "minimum value"))
        self.label_3.setText(_translate("ColorBarPropertyDlg", "maximum value"))
        self.checkBox_inverse.setText(_translate("ColorBarPropertyDlg", "inverse"))
        self.pushButton_apply.setText(_translate("ColorBarPropertyDlg", "Apply"))
        self.pushButton_close.setText(_translate("ColorBarPropertyDlg", "Close"))

