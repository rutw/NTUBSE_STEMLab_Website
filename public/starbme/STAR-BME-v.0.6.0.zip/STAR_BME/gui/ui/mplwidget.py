#from PyQt4 import QtGui
from qgis.PyQt.QtWidgets import QWidget
from qgis.PyQt.QtWidgets import * 
import matplotlib
matplotlib.use("QT5Agg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt4agg \
  import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg \
  import NavigationToolbar2QT as NavigationToolbar
from matplotlib import cm
class MplCanvas(FigureCanvas):
    def __init__(self):
        self.fig = Figure()
        self.ax = self.fig.add_subplot(111)
        FigureCanvas.__init__(self, self.fig)
        # FigureCanvas.setSizePolicy(self,
        #                  QtGui.QSizePolicy.Expanding,
        #                  QtGui.QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

class MplWidget(QWidget):
    def __init__(self, parent = None):
        QWidget.__init__(self, parent)
        self.canvas = MplCanvas()
        self.vbl = QVBoxLayout()
        self.vbl.addWidget(self.canvas) 
        self.ntb = NavigationToolbar(self.canvas,self)
        self.vbl.addWidget(self.ntb)
        self.setLayout(self.vbl)
        
class MplWidgetWithoutNavTools(QWidget):
    def __init__(self, parent = None):
        QWidget.__init__(self, parent)
        self.canvas = MplCanvas()
        self.vbl = QVBoxLayout()
        self.vbl.addWidget(self.canvas)
        self.setLayout(self.vbl)
