# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_TimeBarDockWgt.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_TimeBarDockWgt(object):
    def setupUi(self, TimeBarDockWgt):
        TimeBarDockWgt.setObjectName("TimeBarDockWgt")
        TimeBarDockWgt.resize(545, 91)
        TimeBarDockWgt.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea|QtCore.Qt.TopDockWidgetArea)
        self.dockWidgetContents = QtWidgets.QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        self.gridLayout = QtWidgets.QGridLayout(self.dockWidgetContents)
        self.gridLayout.setObjectName("gridLayout")
        self.label_time = QtWidgets.QLabel(self.dockWidgetContents)
        self.label_time.setAlignment(QtCore.Qt.AlignCenter)
        self.label_time.setObjectName("label_time")
        self.gridLayout.addWidget(self.label_time, 0, 1, 1, 1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.radioButton_mean = QtWidgets.QRadioButton(self.dockWidgetContents)
        self.radioButton_mean.setEnabled(False)
        self.radioButton_mean.setChecked(True)
        self.radioButton_mean.setObjectName("radioButton_mean")
        self.buttonGroup = QtWidgets.QButtonGroup(TimeBarDockWgt)
        self.buttonGroup.setObjectName("buttonGroup")
        self.buttonGroup.addButton(self.radioButton_mean)
        self.horizontalLayout.addWidget(self.radioButton_mean)
        self.radioButton_variance = QtWidgets.QRadioButton(self.dockWidgetContents)
        self.radioButton_variance.setEnabled(False)
        self.radioButton_variance.setObjectName("radioButton_variance")
        self.buttonGroup.addButton(self.radioButton_variance)
        self.horizontalLayout.addWidget(self.radioButton_variance)
        self.gridLayout.addLayout(self.horizontalLayout, 0, 3, 1, 1)
        self.pushButton_previous = QtWidgets.QPushButton(self.dockWidgetContents)
        self.pushButton_previous.setMaximumSize(QtCore.QSize(21, 23))
        self.pushButton_previous.setObjectName("pushButton_previous")
        self.gridLayout.addWidget(self.pushButton_previous, 1, 0, 1, 1)
        self.horizontalSlider = TimeBarSlider(self.dockWidgetContents)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.horizontalSlider.sizePolicy().hasHeightForWidth())
        self.horizontalSlider.setSizePolicy(sizePolicy)
        self.horizontalSlider.setPageStep(1)
        self.horizontalSlider.setProperty("value", 0)
        self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider.setInvertedAppearance(False)
        self.horizontalSlider.setInvertedControls(False)
        self.horizontalSlider.setTickPosition(QtWidgets.QSlider.TicksAbove)
        self.horizontalSlider.setTickInterval(0)
        self.horizontalSlider.setObjectName("horizontalSlider")
        self.gridLayout.addWidget(self.horizontalSlider, 1, 1, 1, 1)
        self.pushButton_next = QtWidgets.QPushButton(self.dockWidgetContents)
        self.pushButton_next.setMaximumSize(QtCore.QSize(21, 23))
        self.pushButton_next.setObjectName("pushButton_next")
        self.gridLayout.addWidget(self.pushButton_next, 1, 2, 1, 1)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.pushButton_draw = QtWidgets.QPushButton(self.dockWidgetContents)
        self.pushButton_draw.setObjectName("pushButton_draw")
        self.horizontalLayout_2.addWidget(self.pushButton_draw)
        self.checkBox_autodraw = QtWidgets.QCheckBox(self.dockWidgetContents)
        self.checkBox_autodraw.setObjectName("checkBox_autodraw")
        self.horizontalLayout_2.addWidget(self.checkBox_autodraw)
        self.gridLayout.addLayout(self.horizontalLayout_2, 1, 3, 1, 1)
        TimeBarDockWgt.setWidget(self.dockWidgetContents)

        self.retranslateUi(TimeBarDockWgt)
        QtCore.QMetaObject.connectSlotsByName(TimeBarDockWgt)

    def retranslateUi(self, TimeBarDockWgt):
        _translate = QtCore.QCoreApplication.translate
        TimeBarDockWgt.setWindowTitle(_translate("TimeBarDockWgt", "TimeBar"))
        self.label_time.setText(_translate("TimeBarDockWgt", "Time = "))
        self.radioButton_mean.setText(_translate("TimeBarDockWgt", "Mean"))
        self.radioButton_variance.setText(_translate("TimeBarDockWgt", "Variance"))
        self.pushButton_previous.setText(_translate("TimeBarDockWgt", "<"))
        self.pushButton_next.setText(_translate("TimeBarDockWgt", ">"))
        self.pushButton_draw.setText(_translate("TimeBarDockWgt", "Draw"))
        self.checkBox_autodraw.setText(_translate("TimeBarDockWgt", "Auto Draw"))

from .mycustomwgt import TimeBarSlider
