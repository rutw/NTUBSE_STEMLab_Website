# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_OptionDlg.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_OptionDlg(object):
    def setupUi(self, OptionDlg):
        OptionDlg.setObjectName("OptionDlg")
        OptionDlg.resize(400, 74)
        self.verticalLayout = QtWidgets.QVBoxLayout(OptionDlg)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(OptionDlg)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.comboBox_detrend = QtWidgets.QComboBox(OptionDlg)
        self.comboBox_detrend.setObjectName("comboBox_detrend")
        self.horizontalLayout.addWidget(self.comboBox_detrend)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.pushButton_default = QtWidgets.QPushButton(OptionDlg)
        self.pushButton_default.setObjectName("pushButton_default")
        self.horizontalLayout_2.addWidget(self.pushButton_default)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.pushButton_ok = QtWidgets.QPushButton(OptionDlg)
        self.pushButton_ok.setObjectName("pushButton_ok")
        self.horizontalLayout_2.addWidget(self.pushButton_ok)
        self.pushButton_cancel = QtWidgets.QPushButton(OptionDlg)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.horizontalLayout_2.addWidget(self.pushButton_cancel)
        self.pushButton_apply = QtWidgets.QPushButton(OptionDlg)
        self.pushButton_apply.setObjectName("pushButton_apply")
        self.horizontalLayout_2.addWidget(self.pushButton_apply)
        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.retranslateUi(OptionDlg)
        QtCore.QMetaObject.connectSlotsByName(OptionDlg)

    def retranslateUi(self, OptionDlg):
        _translate = QtCore.QCoreApplication.translate
        OptionDlg.setWindowTitle(_translate("OptionDlg", "STAR-BME Configure"))
        self.label.setText(_translate("OptionDlg", "Default Detrend Method"))
        self.pushButton_default.setText(_translate("OptionDlg", "Set it to default"))
        self.pushButton_ok.setText(_translate("OptionDlg", "Ok"))
        self.pushButton_cancel.setText(_translate("OptionDlg", "Cancel"))
        self.pushButton_apply.setText(_translate("OptionDlg", "Apply"))

