# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_SelectShpDlg.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SelectShpDlg(object):
    def setupUi(self, SelectShpDlg):
        SelectShpDlg.setObjectName("SelectShpDlg")
        SelectShpDlg.resize(365, 102)
        self.verticalLayout = QtWidgets.QVBoxLayout(SelectShpDlg)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label = QtWidgets.QLabel(SelectShpDlg)
        self.label.setObjectName("label")
        self.horizontalLayout_3.addWidget(self.label)
        self.lineEdit_filename = QtWidgets.QLineEdit(SelectShpDlg)
        self.lineEdit_filename.setReadOnly(True)
        self.lineEdit_filename.setObjectName("lineEdit_filename")
        self.horizontalLayout_3.addWidget(self.lineEdit_filename)
        self.pushButton_browse = QtWidgets.QPushButton(SelectShpDlg)
        self.pushButton_browse.setObjectName("pushButton_browse")
        self.horizontalLayout_3.addWidget(self.pushButton_browse)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_37 = QtWidgets.QLabel(SelectShpDlg)
        self.label_37.setObjectName("label_37")
        self.horizontalLayout.addWidget(self.label_37)
        self.lineEdit_tmin = QtWidgets.QLineEdit(SelectShpDlg)
        self.lineEdit_tmin.setText("")
        self.lineEdit_tmin.setObjectName("lineEdit_tmin")
        self.horizontalLayout.addWidget(self.lineEdit_tmin)
        self.label_38 = QtWidgets.QLabel(SelectShpDlg)
        self.label_38.setObjectName("label_38")
        self.horizontalLayout.addWidget(self.label_38)
        self.lineEdit_tmax = QtWidgets.QLineEdit(SelectShpDlg)
        self.lineEdit_tmax.setText("")
        self.lineEdit_tmax.setObjectName("lineEdit_tmax")
        self.horizontalLayout.addWidget(self.lineEdit_tmax)
        self.label_42 = QtWidgets.QLabel(SelectShpDlg)
        self.label_42.setObjectName("label_42")
        self.horizontalLayout.addWidget(self.label_42)
        self.lineEdit_tn = QtWidgets.QLineEdit(SelectShpDlg)
        self.lineEdit_tn.setText("")
        self.lineEdit_tn.setObjectName("lineEdit_tn")
        self.horizontalLayout.addWidget(self.lineEdit_tn)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.pushButton_ok = QtWidgets.QPushButton(SelectShpDlg)
        self.pushButton_ok.setObjectName("pushButton_ok")
        self.horizontalLayout_2.addWidget(self.pushButton_ok)
        self.pushButton_cancel = QtWidgets.QPushButton(SelectShpDlg)
        self.pushButton_cancel.setObjectName("pushButton_cancel")
        self.horizontalLayout_2.addWidget(self.pushButton_cancel)
        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.retranslateUi(SelectShpDlg)
        QtCore.QMetaObject.connectSlotsByName(SelectShpDlg)

    def retranslateUi(self, SelectShpDlg):
        _translate = QtCore.QCoreApplication.translate
        SelectShpDlg.setWindowTitle(_translate("SelectShpDlg", "Select Shape File Dialog"))
        self.label.setText(_translate("SelectShpDlg", "File Name"))
        self.pushButton_browse.setText(_translate("SelectShpDlg", "Browse..."))
        self.label_37.setText(_translate("SelectShpDlg", "Tmin:"))
        self.label_38.setText(_translate("SelectShpDlg", "Tmax:"))
        self.label_42.setText(_translate("SelectShpDlg", "Tn:"))
        self.pushButton_ok.setText(_translate("SelectShpDlg", "Ok"))
        self.pushButton_cancel.setText(_translate("SelectShpDlg", "Cancel"))

