# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_TaskWgt.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_TaskWgt(object):
    def setupUi(self, TaskWgt):
        TaskWgt.setObjectName("TaskWgt")
        TaskWgt.resize(400, 74)
        self.verticalLayout = QtWidgets.QVBoxLayout(TaskWgt)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(TaskWgt)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButton_setup = QtWidgets.QPushButton(TaskWgt)
        self.pushButton_setup.setObjectName("pushButton_setup")
        self.horizontalLayout.addWidget(self.pushButton_setup)
        self.pushButton_proccess = QtWidgets.QPushButton(TaskWgt)
        self.pushButton_proccess.setObjectName("pushButton_proccess")
        self.horizontalLayout.addWidget(self.pushButton_proccess)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.progressBar = QtWidgets.QProgressBar(TaskWgt)
        self.progressBar.setProperty("value", 24)
        self.progressBar.setObjectName("progressBar")
        self.horizontalLayout_2.addWidget(self.progressBar)
        self.pushButton_showdetail = QtWidgets.QPushButton(TaskWgt)
        self.pushButton_showdetail.setObjectName("pushButton_showdetail")
        self.horizontalLayout_2.addWidget(self.pushButton_showdetail)
        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.retranslateUi(TaskWgt)
        QtCore.QMetaObject.connectSlotsByName(TaskWgt)

    def retranslateUi(self, TaskWgt):
        _translate = QtCore.QCoreApplication.translate
        TaskWgt.setWindowTitle(_translate("TaskWgt", "Form"))
        self.label.setText(_translate("TaskWgt", "TextLabel"))
        self.pushButton_setup.setText(_translate("TaskWgt", "Setup..."))
        self.pushButton_proccess.setText(_translate("TaskWgt", "Proccess"))
        self.pushButton_showdetail.setText(_translate("TaskWgt", "Show Detail"))

