# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_ColorBarDockWgt.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_ColorBarDockWgt(object):
    def setupUi(self, ColorBarDockWgt):
        ColorBarDockWgt.setObjectName("ColorBarDockWgt")
        ColorBarDockWgt.resize(94, 444)
        ColorBarDockWgt.setAllowedAreas(QtCore.Qt.LeftDockWidgetArea|QtCore.Qt.RightDockWidgetArea)
        self.dockWidgetContents = QtWidgets.QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName("verticalLayout")
        self.widget = MplWidgetWithoutNavTools(self.dockWidgetContents)
        self.widget.setObjectName("widget")
        self.verticalLayout.addWidget(self.widget)
        self.pushButton_changeproperty = QtWidgets.QPushButton(self.dockWidgetContents)
        self.pushButton_changeproperty.setObjectName("pushButton_changeproperty")
        self.verticalLayout.addWidget(self.pushButton_changeproperty)
        ColorBarDockWgt.setWidget(self.dockWidgetContents)

        self.retranslateUi(ColorBarDockWgt)
        QtCore.QMetaObject.connectSlotsByName(ColorBarDockWgt)

    def retranslateUi(self, ColorBarDockWgt):
        _translate = QtCore.QCoreApplication.translate
        ColorBarDockWgt.setWindowTitle(_translate("ColorBarDockWgt", "ColorBar"))
        self.pushButton_changeproperty.setText(_translate("ColorBarDockWgt", "Change\n"
" Property..."))

from .mplwidget import MplWidgetWithoutNavTools
