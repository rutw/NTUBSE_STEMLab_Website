# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_MplDlg.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MplDlg(object):
    def setupUi(self, MplDlg):
        MplDlg.setObjectName("MplDlg")
        MplDlg.resize(777, 541)
        self.verticalLayout = QtWidgets.QVBoxLayout(MplDlg)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(MplDlg)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.comboBox = QtWidgets.QComboBox(MplDlg)
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.horizontalLayout.addWidget(self.comboBox)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.mplWidget = MplWidget(MplDlg)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.mplWidget.sizePolicy().hasHeightForWidth())
        self.mplWidget.setSizePolicy(sizePolicy)
        self.mplWidget.setMinimumSize(QtCore.QSize(250, 250))
        self.mplWidget.setObjectName("mplWidget")
        self.verticalLayout.addWidget(self.mplWidget)

        self.retranslateUi(MplDlg)
        QtCore.QMetaObject.connectSlotsByName(MplDlg)

    def retranslateUi(self, MplDlg):
        _translate = QtCore.QCoreApplication.translate
        MplDlg.setWindowTitle(_translate("MplDlg", "Mpl Dialog"))
        self.label.setText(_translate("MplDlg", "Selected Variable:"))
        self.comboBox.setItemText(0, _translate("MplDlg", "RMSE"))
        self.comboBox.setItemText(1, _translate("MplDlg", "Mean"))
        self.comboBox.setItemText(2, _translate("MplDlg", "Standard deviation"))
        self.comboBox.setItemText(3, _translate("MplDlg", "25 percentile"))
        self.comboBox.setItemText(4, _translate("MplDlg", "Median"))
        self.comboBox.setItemText(5, _translate("MplDlg", "75 percentile"))
        self.comboBox.setItemText(6, _translate("MplDlg", "Min"))
        self.comboBox.setItemText(7, _translate("MplDlg", "Max"))

from .mplwidget import MplWidget
