# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_ViewDataDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ViewDataDlg(object):
    def setupUi(self, ViewDataDlg):
        ViewDataDlg.setObjectName(_fromUtf8("ViewDataDlg"))
        ViewDataDlg.resize(777, 444)
        self.verticalLayout = QtGui.QVBoxLayout(ViewDataDlg)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.mplWidget = MplWidget(ViewDataDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.mplWidget.sizePolicy().hasHeightForWidth())
        self.mplWidget.setSizePolicy(sizePolicy)
        self.mplWidget.setMinimumSize(QtCore.QSize(250, 250))
        self.mplWidget.setObjectName(_fromUtf8("mplWidget"))
        self.verticalLayout.addWidget(self.mplWidget)
        self.checkBox_showtrend = QtGui.QCheckBox(ViewDataDlg)
        self.checkBox_showtrend.setObjectName(_fromUtf8("checkBox_showtrend"))
        self.verticalLayout.addWidget(self.checkBox_showtrend)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.checkBox_alldatascale = QtGui.QCheckBox(ViewDataDlg)
        self.checkBox_alldatascale.setObjectName(_fromUtf8("checkBox_alldatascale"))
        self.horizontalLayout.addWidget(self.checkBox_alldatascale)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButton_close = QtGui.QPushButton(ViewDataDlg)
        self.pushButton_close.setObjectName(_fromUtf8("pushButton_close"))
        self.horizontalLayout.addWidget(self.pushButton_close)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(ViewDataDlg)
        QtCore.QMetaObject.connectSlotsByName(ViewDataDlg)

    def retranslateUi(self, ViewDataDlg):
        ViewDataDlg.setWindowTitle(_translate("ViewDataDlg", "View Data Dialog", None))
        self.checkBox_showtrend.setText(_translate("ViewDataDlg", "Show Trend", None))
        self.checkBox_alldatascale.setText(_translate("ViewDataDlg", "Use All Data Scale", None))
        self.pushButton_close.setText(_translate("ViewDataDlg", "Close", None))

from mplwidget import MplWidget
