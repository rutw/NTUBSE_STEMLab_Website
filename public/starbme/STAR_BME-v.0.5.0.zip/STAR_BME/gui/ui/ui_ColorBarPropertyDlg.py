# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_ColorBarPropertyDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ColorBarPropertyDlg(object):
    def setupUi(self, ColorBarPropertyDlg):
        ColorBarPropertyDlg.setObjectName(_fromUtf8("ColorBarPropertyDlg"))
        ColorBarPropertyDlg.resize(299, 127)
        self.verticalLayout_3 = QtGui.QVBoxLayout(ColorBarPropertyDlg)
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label = QtGui.QLabel(ColorBarPropertyDlg)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_2.addWidget(self.label)
        self.label_2 = QtGui.QLabel(ColorBarPropertyDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout_2.addWidget(self.label_2)
        self.label_3 = QtGui.QLabel(ColorBarPropertyDlg)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.verticalLayout_2.addWidget(self.label_3)
        self.horizontalLayout_3.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.comboBox_cmap = QtGui.QComboBox(ColorBarPropertyDlg)
        self.comboBox_cmap.setObjectName(_fromUtf8("comboBox_cmap"))
        self.horizontalLayout_2.addWidget(self.comboBox_cmap)
        self.checkBox_inverse = QtGui.QCheckBox(ColorBarPropertyDlg)
        self.checkBox_inverse.setObjectName(_fromUtf8("checkBox_inverse"))
        self.horizontalLayout_2.addWidget(self.checkBox_inverse)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.lineEdit_minvalue = QtGui.QLineEdit(ColorBarPropertyDlg)
        self.lineEdit_minvalue.setObjectName(_fromUtf8("lineEdit_minvalue"))
        self.verticalLayout.addWidget(self.lineEdit_minvalue)
        self.lineEdit_maxvalue = QtGui.QLineEdit(ColorBarPropertyDlg)
        self.lineEdit_maxvalue.setObjectName(_fromUtf8("lineEdit_maxvalue"))
        self.verticalLayout.addWidget(self.lineEdit_maxvalue)
        self.horizontalLayout_3.addLayout(self.verticalLayout)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.pushButton_apply = QtGui.QPushButton(ColorBarPropertyDlg)
        self.pushButton_apply.setObjectName(_fromUtf8("pushButton_apply"))
        self.horizontalLayout.addWidget(self.pushButton_apply)
        self.pushButton_close = QtGui.QPushButton(ColorBarPropertyDlg)
        self.pushButton_close.setObjectName(_fromUtf8("pushButton_close"))
        self.horizontalLayout.addWidget(self.pushButton_close)
        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.retranslateUi(ColorBarPropertyDlg)
        QtCore.QMetaObject.connectSlotsByName(ColorBarPropertyDlg)

    def retranslateUi(self, ColorBarPropertyDlg):
        ColorBarPropertyDlg.setWindowTitle(_translate("ColorBarPropertyDlg", "ColorBar - Property", None))
        self.label.setText(_translate("ColorBarPropertyDlg", "color map", None))
        self.label_2.setText(_translate("ColorBarPropertyDlg", "minimum value", None))
        self.label_3.setText(_translate("ColorBarPropertyDlg", "maximum value", None))
        self.checkBox_inverse.setText(_translate("ColorBarPropertyDlg", "inverse", None))
        self.pushButton_apply.setText(_translate("ColorBarPropertyDlg", "Apply", None))
        self.pushButton_close.setText(_translate("ColorBarPropertyDlg", "Close", None))

