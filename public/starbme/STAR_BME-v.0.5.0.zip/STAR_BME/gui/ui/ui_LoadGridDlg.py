# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_LoadGridDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_LoadGridDlg(object):
    def setupUi(self, LoadGridDlg):
        LoadGridDlg.setObjectName(_fromUtf8("LoadGridDlg"))
        LoadGridDlg.resize(386, 158)
        self.verticalLayout = QtGui.QVBoxLayout(LoadGridDlg)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.pushButton_setbydata = QtGui.QPushButton(LoadGridDlg)
        self.pushButton_setbydata.setObjectName(_fromUtf8("pushButton_setbydata"))
        self.horizontalLayout_2.addWidget(self.pushButton_setbydata)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_24 = QtGui.QHBoxLayout()
        self.horizontalLayout_24.setObjectName(_fromUtf8("horizontalLayout_24"))
        self.label_33 = QtGui.QLabel(LoadGridDlg)
        self.label_33.setObjectName(_fromUtf8("label_33"))
        self.horizontalLayout_24.addWidget(self.label_33)
        self.lineEdit_xmin = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_xmin.setText(_fromUtf8(""))
        self.lineEdit_xmin.setObjectName(_fromUtf8("lineEdit_xmin"))
        self.horizontalLayout_24.addWidget(self.lineEdit_xmin)
        self.label_32 = QtGui.QLabel(LoadGridDlg)
        self.label_32.setObjectName(_fromUtf8("label_32"))
        self.horizontalLayout_24.addWidget(self.label_32)
        self.lineEdit_xmax = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_xmax.setText(_fromUtf8(""))
        self.lineEdit_xmax.setObjectName(_fromUtf8("lineEdit_xmax"))
        self.horizontalLayout_24.addWidget(self.lineEdit_xmax)
        self.label_39 = QtGui.QLabel(LoadGridDlg)
        self.label_39.setObjectName(_fromUtf8("label_39"))
        self.horizontalLayout_24.addWidget(self.label_39)
        self.lineEdit_xn = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_xn.setText(_fromUtf8(""))
        self.lineEdit_xn.setObjectName(_fromUtf8("lineEdit_xn"))
        self.horizontalLayout_24.addWidget(self.lineEdit_xn)
        self.verticalLayout.addLayout(self.horizontalLayout_24)
        self.horizontalLayout_25 = QtGui.QHBoxLayout()
        self.horizontalLayout_25.setObjectName(_fromUtf8("horizontalLayout_25"))
        self.label_36 = QtGui.QLabel(LoadGridDlg)
        self.label_36.setObjectName(_fromUtf8("label_36"))
        self.horizontalLayout_25.addWidget(self.label_36)
        self.lineEdit_ymin = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_ymin.setText(_fromUtf8(""))
        self.lineEdit_ymin.setObjectName(_fromUtf8("lineEdit_ymin"))
        self.horizontalLayout_25.addWidget(self.lineEdit_ymin)
        self.label_34 = QtGui.QLabel(LoadGridDlg)
        self.label_34.setObjectName(_fromUtf8("label_34"))
        self.horizontalLayout_25.addWidget(self.label_34)
        self.lineEdit_ymax = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_ymax.setText(_fromUtf8(""))
        self.lineEdit_ymax.setObjectName(_fromUtf8("lineEdit_ymax"))
        self.horizontalLayout_25.addWidget(self.lineEdit_ymax)
        self.label_41 = QtGui.QLabel(LoadGridDlg)
        self.label_41.setObjectName(_fromUtf8("label_41"))
        self.horizontalLayout_25.addWidget(self.label_41)
        self.lineEdit_yn = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_yn.setText(_fromUtf8(""))
        self.lineEdit_yn.setObjectName(_fromUtf8("lineEdit_yn"))
        self.horizontalLayout_25.addWidget(self.lineEdit_yn)
        self.verticalLayout.addLayout(self.horizontalLayout_25)
        self.horizontalLayout_26 = QtGui.QHBoxLayout()
        self.horizontalLayout_26.setObjectName(_fromUtf8("horizontalLayout_26"))
        self.label_37 = QtGui.QLabel(LoadGridDlg)
        self.label_37.setObjectName(_fromUtf8("label_37"))
        self.horizontalLayout_26.addWidget(self.label_37)
        self.lineEdit_tmin = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_tmin.setText(_fromUtf8(""))
        self.lineEdit_tmin.setObjectName(_fromUtf8("lineEdit_tmin"))
        self.horizontalLayout_26.addWidget(self.lineEdit_tmin)
        self.label_38 = QtGui.QLabel(LoadGridDlg)
        self.label_38.setObjectName(_fromUtf8("label_38"))
        self.horizontalLayout_26.addWidget(self.label_38)
        self.lineEdit_tmax = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_tmax.setText(_fromUtf8(""))
        self.lineEdit_tmax.setObjectName(_fromUtf8("lineEdit_tmax"))
        self.horizontalLayout_26.addWidget(self.lineEdit_tmax)
        self.label_42 = QtGui.QLabel(LoadGridDlg)
        self.label_42.setObjectName(_fromUtf8("label_42"))
        self.horizontalLayout_26.addWidget(self.label_42)
        self.lineEdit_tn = QtGui.QLineEdit(LoadGridDlg)
        self.lineEdit_tn.setText(_fromUtf8(""))
        self.lineEdit_tn.setObjectName(_fromUtf8("lineEdit_tn"))
        self.horizontalLayout_26.addWidget(self.lineEdit_tn)
        self.verticalLayout.addLayout(self.horizontalLayout_26)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.pushButton_ok = QtGui.QPushButton(LoadGridDlg)
        self.pushButton_ok.setObjectName(_fromUtf8("pushButton_ok"))
        self.horizontalLayout.addWidget(self.pushButton_ok)
        self.pushButton_cancel = QtGui.QPushButton(LoadGridDlg)
        self.pushButton_cancel.setObjectName(_fromUtf8("pushButton_cancel"))
        self.horizontalLayout.addWidget(self.pushButton_cancel)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(LoadGridDlg)
        QtCore.QMetaObject.connectSlotsByName(LoadGridDlg)

    def retranslateUi(self, LoadGridDlg):
        LoadGridDlg.setWindowTitle(_translate("LoadGridDlg", "Load Grid Dialog", None))
        self.pushButton_setbydata.setText(_translate("LoadGridDlg", "Set By Data Boundary", None))
        self.label_33.setText(_translate("LoadGridDlg", "Xmin:", None))
        self.label_32.setText(_translate("LoadGridDlg", "Xmax:", None))
        self.label_39.setText(_translate("LoadGridDlg", "Xn:", None))
        self.label_36.setText(_translate("LoadGridDlg", "Ymin:", None))
        self.label_34.setText(_translate("LoadGridDlg", "Ymax:", None))
        self.label_41.setText(_translate("LoadGridDlg", "Yn:", None))
        self.label_37.setText(_translate("LoadGridDlg", "Tmin:", None))
        self.label_38.setText(_translate("LoadGridDlg", "Tmax:", None))
        self.label_42.setText(_translate("LoadGridDlg", "Tn:", None))
        self.pushButton_ok.setText(_translate("LoadGridDlg", "OK", None))
        self.pushButton_cancel.setText(_translate("LoadGridDlg", "Cancel", None))

