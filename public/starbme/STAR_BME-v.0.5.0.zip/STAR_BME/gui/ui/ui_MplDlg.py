# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_MplDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MplDlg(object):
    def setupUi(self, MplDlg):
        MplDlg.setObjectName(_fromUtf8("MplDlg"))
        MplDlg.resize(777, 444)
        self.verticalLayout = QtGui.QVBoxLayout(MplDlg)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(MplDlg)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        self.comboBox = QtGui.QComboBox(MplDlg)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.horizontalLayout.addWidget(self.comboBox)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.mplWidget = MplWidget(MplDlg)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.mplWidget.sizePolicy().hasHeightForWidth())
        self.mplWidget.setSizePolicy(sizePolicy)
        self.mplWidget.setMinimumSize(QtCore.QSize(250, 250))
        self.mplWidget.setObjectName(_fromUtf8("mplWidget"))
        self.verticalLayout.addWidget(self.mplWidget)

        self.retranslateUi(MplDlg)
        QtCore.QMetaObject.connectSlotsByName(MplDlg)

    def retranslateUi(self, MplDlg):
        MplDlg.setWindowTitle(_translate("MplDlg", "Mpl Dialog", None))
        self.label.setText(_translate("MplDlg", "Selected Variable:", None))
        self.comboBox.setItemText(0, _translate("MplDlg", "RMSE", None))
        self.comboBox.setItemText(1, _translate("MplDlg", "Mean", None))
        self.comboBox.setItemText(2, _translate("MplDlg", "Standard deviation", None))
        self.comboBox.setItemText(3, _translate("MplDlg", "25 percentile", None))
        self.comboBox.setItemText(4, _translate("MplDlg", "Median", None))
        self.comboBox.setItemText(5, _translate("MplDlg", "75 percentile", None))
        self.comboBox.setItemText(6, _translate("MplDlg", "Min", None))
        self.comboBox.setItemText(7, _translate("MplDlg", "Max", None))

from mplwidget import MplWidget
