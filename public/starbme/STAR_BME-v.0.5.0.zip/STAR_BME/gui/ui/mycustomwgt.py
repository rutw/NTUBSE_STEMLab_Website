from PyQt4.QtCore import *
from PyQt4.QtGui import *

class TimeBarSlider(QSlider):
    canDrawNow = pyqtSignal()
    def __init__(self, parent = None):
        QSlider.__init__(self, parent)
    def mouseReleaseEvent( self, ev ):
        QSlider.mouseReleaseEvent(self,ev)