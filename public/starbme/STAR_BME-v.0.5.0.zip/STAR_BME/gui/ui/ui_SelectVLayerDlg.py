# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_SelectVLayerDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_SelectVLayerDlg(object):
    def setupUi(self, SelectVLayerDlg):
        SelectVLayerDlg.setObjectName(_fromUtf8("SelectVLayerDlg"))
        SelectVLayerDlg.setWindowModality(QtCore.Qt.WindowModal)
        SelectVLayerDlg.resize(296, 69)
        self.verticalLayout = QtGui.QVBoxLayout(SelectVLayerDlg)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(SelectVLayerDlg)
        self.label.setMinimumSize(QtCore.QSize(77, 16))
        self.label.setMaximumSize(QtCore.QSize(77, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        self.comboBox = QtGui.QComboBox(SelectVLayerDlg)
        self.comboBox.setMinimumSize(QtCore.QSize(171, 20))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.horizontalLayout.addWidget(self.comboBox)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.buttonBox = QtGui.QDialogButtonBox(SelectVLayerDlg)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(SelectVLayerDlg)
        QtCore.QMetaObject.connectSlotsByName(SelectVLayerDlg)

    def retranslateUi(self, SelectVLayerDlg):
        SelectVLayerDlg.setWindowTitle(_translate("SelectVLayerDlg", "Dialog", None))
        self.label.setText(_translate("SelectVLayerDlg", "Select the Layer:", None))

