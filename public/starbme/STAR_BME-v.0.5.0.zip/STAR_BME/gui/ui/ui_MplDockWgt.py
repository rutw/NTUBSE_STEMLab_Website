# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_MplDockWgt.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MplDockWgt(object):
    def setupUi(self, MplDockWgt):
        MplDockWgt.setObjectName(_fromUtf8("MplDockWgt"))
        MplDockWgt.resize(413, 379)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.verticalLayout = QtGui.QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.mplWidget = MplWidget(self.dockWidgetContents)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.mplWidget.sizePolicy().hasHeightForWidth())
        self.mplWidget.setSizePolicy(sizePolicy)
        self.mplWidget.setMinimumSize(QtCore.QSize(250, 250))
        self.mplWidget.setObjectName(_fromUtf8("mplWidget"))
        self.verticalLayout.addWidget(self.mplWidget)
        self.horizontalSlider = QtGui.QSlider(self.dockWidgetContents)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.horizontalSlider.sizePolicy().hasHeightForWidth())
        self.horizontalSlider.setSizePolicy(sizePolicy)
        self.horizontalSlider.setPageStep(1)
        self.horizontalSlider.setProperty("value", 0)
        self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider.setInvertedAppearance(False)
        self.horizontalSlider.setInvertedControls(False)
        self.horizontalSlider.setTickPosition(QtGui.QSlider.TicksAbove)
        self.horizontalSlider.setTickInterval(0)
        self.horizontalSlider.setObjectName(_fromUtf8("horizontalSlider"))
        self.verticalLayout.addWidget(self.horizontalSlider)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.comboBox_data = QtGui.QComboBox(self.dockWidgetContents)
        self.comboBox_data.setObjectName(_fromUtf8("comboBox_data"))
        self.horizontalLayout_3.addWidget(self.comboBox_data)
        self.comboBox_stationtime = QtGui.QComboBox(self.dockWidgetContents)
        self.comboBox_stationtime.setObjectName(_fromUtf8("comboBox_stationtime"))
        self.comboBox_stationtime.addItem(_fromUtf8(""))
        self.comboBox_stationtime.addItem(_fromUtf8(""))
        self.horizontalLayout_3.addWidget(self.comboBox_stationtime)
        self.label = QtGui.QLabel(self.dockWidgetContents)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout_3.addWidget(self.label)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_9 = QtGui.QHBoxLayout()
        self.horizontalLayout_9.setObjectName(_fromUtf8("horizontalLayout_9"))
        self.pushButton = QtGui.QPushButton(self.dockWidgetContents)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.horizontalLayout_9.addWidget(self.pushButton)
        self.checkBox = QtGui.QCheckBox(self.dockWidgetContents)
        self.checkBox.setObjectName(_fromUtf8("checkBox"))
        self.horizontalLayout_9.addWidget(self.checkBox)
        self.verticalLayout.addLayout(self.horizontalLayout_9)
        MplDockWgt.setWidget(self.dockWidgetContents)

        self.retranslateUi(MplDockWgt)
        QtCore.QMetaObject.connectSlotsByName(MplDockWgt)

    def retranslateUi(self, MplDockWgt):
        MplDockWgt.setWindowTitle(_translate("MplDockWgt", "Data Visualization", None))
        self.comboBox_stationtime.setItemText(0, _translate("MplDockWgt", "At Station", None))
        self.comboBox_stationtime.setItemText(1, _translate("MplDockWgt", "At Time", None))
        self.label.setText(_translate("MplDockWgt", "Name Or Time", None))
        self.pushButton.setText(_translate("MplDockWgt", "Draw", None))
        self.checkBox.setText(_translate("MplDockWgt", "Auto Draw", None))

from mplwidget import MplWidget
