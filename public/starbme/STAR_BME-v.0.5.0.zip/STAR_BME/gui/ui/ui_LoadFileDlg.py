# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_LoadFileDlg.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_LoadFileDlg(object):
    def setupUi(self, LoadFileDlg):
        LoadFileDlg.setObjectName(_fromUtf8("LoadFileDlg"))
        LoadFileDlg.resize(331, 206)
        self.verticalLayout_2 = QtGui.QVBoxLayout(LoadFileDlg)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.widget_filename = QtGui.QWidget(LoadFileDlg)
        self.widget_filename.setObjectName(_fromUtf8("widget_filename"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout(self.widget_filename)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label = QtGui.QLabel(self.widget_filename)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout_3.addWidget(self.label)
        self.lineEdit_filename = QtGui.QLineEdit(self.widget_filename)
        self.lineEdit_filename.setReadOnly(True)
        self.lineEdit_filename.setObjectName(_fromUtf8("lineEdit_filename"))
        self.horizontalLayout_3.addWidget(self.lineEdit_filename)
        self.pushButton_browse = QtGui.QPushButton(self.widget_filename)
        self.pushButton_browse.setObjectName(_fromUtf8("pushButton_browse"))
        self.horizontalLayout_3.addWidget(self.pushButton_browse)
        self.verticalLayout_2.addWidget(self.widget_filename)
        self.groupBox_delimiters = QtGui.QGroupBox(LoadFileDlg)
        self.groupBox_delimiters.setFlat(False)
        self.groupBox_delimiters.setObjectName(_fromUtf8("groupBox_delimiters"))
        self.verticalLayout = QtGui.QVBoxLayout(self.groupBox_delimiters)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.radioButton_comma = QtGui.QRadioButton(self.groupBox_delimiters)
        self.radioButton_comma.setChecked(True)
        self.radioButton_comma.setObjectName(_fromUtf8("radioButton_comma"))
        self.buttonGroup = QtGui.QButtonGroup(LoadFileDlg)
        self.buttonGroup.setObjectName(_fromUtf8("buttonGroup"))
        self.buttonGroup.addButton(self.radioButton_comma)
        self.horizontalLayout_4.addWidget(self.radioButton_comma)
        self.radioButton_space = QtGui.QRadioButton(self.groupBox_delimiters)
        self.radioButton_space.setObjectName(_fromUtf8("radioButton_space"))
        self.buttonGroup.addButton(self.radioButton_space)
        self.horizontalLayout_4.addWidget(self.radioButton_space)
        self.radioButton_tab = QtGui.QRadioButton(self.groupBox_delimiters)
        self.radioButton_tab.setObjectName(_fromUtf8("radioButton_tab"))
        self.buttonGroup.addButton(self.radioButton_tab)
        self.horizontalLayout_4.addWidget(self.radioButton_tab)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.radioButton_others = QtGui.QRadioButton(self.groupBox_delimiters)
        self.radioButton_others.setObjectName(_fromUtf8("radioButton_others"))
        self.buttonGroup.addButton(self.radioButton_others)
        self.horizontalLayout.addWidget(self.radioButton_others)
        self.lineEdit_others = QtGui.QLineEdit(self.groupBox_delimiters)
        self.lineEdit_others.setEnabled(False)
        self.lineEdit_others.setText(_fromUtf8(""))
        self.lineEdit_others.setObjectName(_fromUtf8("lineEdit_others"))
        self.horizontalLayout.addWidget(self.lineEdit_others)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.verticalLayout_2.addWidget(self.groupBox_delimiters)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_2 = QtGui.QLabel(LoadFileDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout_2.addWidget(self.label_2)
        self.spinBox_row = QtGui.QSpinBox(LoadFileDlg)
        self.spinBox_row.setMinimum(1)
        self.spinBox_row.setMaximum(99)
        self.spinBox_row.setObjectName(_fromUtf8("spinBox_row"))
        self.horizontalLayout_2.addWidget(self.spinBox_row)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem3)
        self.pushButton_ok = QtGui.QPushButton(LoadFileDlg)
        self.pushButton_ok.setObjectName(_fromUtf8("pushButton_ok"))
        self.horizontalLayout_5.addWidget(self.pushButton_ok)
        self.pushButton_cancel = QtGui.QPushButton(LoadFileDlg)
        self.pushButton_cancel.setObjectName(_fromUtf8("pushButton_cancel"))
        self.horizontalLayout_5.addWidget(self.pushButton_cancel)
        self.verticalLayout_2.addLayout(self.horizontalLayout_5)

        self.retranslateUi(LoadFileDlg)
        QtCore.QMetaObject.connectSlotsByName(LoadFileDlg)

    def retranslateUi(self, LoadFileDlg):
        LoadFileDlg.setWindowTitle(_translate("LoadFileDlg", "Load File Dialog", None))
        self.label.setText(_translate("LoadFileDlg", "File Name", None))
        self.pushButton_browse.setText(_translate("LoadFileDlg", "Browse...", None))
        self.groupBox_delimiters.setTitle(_translate("LoadFileDlg", "Delimiters", None))
        self.radioButton_comma.setText(_translate("LoadFileDlg", "Comma", None))
        self.radioButton_space.setText(_translate("LoadFileDlg", "Space", None))
        self.radioButton_tab.setText(_translate("LoadFileDlg", "Tab", None))
        self.radioButton_others.setText(_translate("LoadFileDlg", "Others", None))
        self.label_2.setText(_translate("LoadFileDlg", "Start to read at row", None))
        self.pushButton_ok.setText(_translate("LoadFileDlg", "OK", None))
        self.pushButton_cancel.setText(_translate("LoadFileDlg", "Cancel", None))

