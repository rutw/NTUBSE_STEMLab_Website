# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\scku\Desktop\GitRepos\starbme\starbme_src\gui\ui\ui_TaskWgt.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_TaskWgt(object):
    def setupUi(self, TaskWgt):
        TaskWgt.setObjectName(_fromUtf8("TaskWgt"))
        TaskWgt.resize(400, 74)
        self.verticalLayout = QtGui.QVBoxLayout(TaskWgt)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label = QtGui.QLabel(TaskWgt)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout.addWidget(self.label)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButton_setup = QtGui.QPushButton(TaskWgt)
        self.pushButton_setup.setObjectName(_fromUtf8("pushButton_setup"))
        self.horizontalLayout.addWidget(self.pushButton_setup)
        self.pushButton_proccess = QtGui.QPushButton(TaskWgt)
        self.pushButton_proccess.setObjectName(_fromUtf8("pushButton_proccess"))
        self.horizontalLayout.addWidget(self.pushButton_proccess)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.progressBar = QtGui.QProgressBar(TaskWgt)
        self.progressBar.setProperty("value", 24)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.horizontalLayout_2.addWidget(self.progressBar)
        self.pushButton_showdetail = QtGui.QPushButton(TaskWgt)
        self.pushButton_showdetail.setObjectName(_fromUtf8("pushButton_showdetail"))
        self.horizontalLayout_2.addWidget(self.pushButton_showdetail)
        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.retranslateUi(TaskWgt)
        QtCore.QMetaObject.connectSlotsByName(TaskWgt)

    def retranslateUi(self, TaskWgt):
        TaskWgt.setWindowTitle(_translate("TaskWgt", "Form", None))
        self.label.setText(_translate("TaskWgt", "TextLabel", None))
        self.pushButton_setup.setText(_translate("TaskWgt", "Setup...", None))
        self.pushButton_proccess.setText(_translate("TaskWgt", "Proccess", None))
        self.pushButton_showdetail.setText(_translate("TaskWgt", "Show Detail", None))

