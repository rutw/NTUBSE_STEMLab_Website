def classFactory(iface):
  # load QtBMEobj class from file QtBME.py
  from stbme import BMEPlugin
  BMEdebug=BMEPlugin(iface)
  iface.BMEdebug=BMEdebug
  return BMEdebug



