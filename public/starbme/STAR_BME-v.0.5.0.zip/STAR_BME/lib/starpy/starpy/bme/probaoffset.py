# -*- coding: utf-8 -*-
import numpy
from numbers import Number

def probaoffset( softpdftype, nl ,limi, offset ):
	ns = nl.shape[0]
	if isinstance(offset, Number) or len(offset) == 1:
		offset = offset * numpy.ones((ns,1))

	if softpdftype in [1, 2]:
		return limi - offset
	elif softpdftype in [3, 4]:
		limi[:,[0,2]] -= offset 
		return limi