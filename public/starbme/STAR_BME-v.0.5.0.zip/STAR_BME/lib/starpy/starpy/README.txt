STARPY dependence:

Special package dependences: Suggested to be imported
1) cubature installation
Functions: cubature
2) nlopt installation
Functions: covmodelfit
3) rpy2 
Functions: stl, dlnm, gam

R:
    dlnm
    mgcv


Inherent package dependences: Required to be imported
3) scipy
4) numpy
5) pandas
6) multiprocessing



